#include <stdio.h>

main()
{
    char ltr = 'b';
    char *ptr_ltr = &ltr;

    printf("(1) b\n\n");
    printf("(2) %p\n\n", &ltr);   

    *ptr_ltr = 'd';
    
    printf("(3) %c\n", *ptr_ltr);

}