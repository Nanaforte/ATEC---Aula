#include <stdio.h>
main()
{
    //variable com valor 10
    int variavel = 10;

    //pointer para int
    int *int_ptr;

    //pointer recebe endereço da variable que tem 10
    int_ptr = &variavel;

    //variable x 
    int x;

    //x recebe valor do endereço apontado pelo pointer
    x = *int_ptr;

    printf("variavel = %d, x = %d\n", variavel, x);

}